//: Playground - noun: a place where people can play

import UIKit

// 1. 짝수와 홀수의 개수 출력

let array=[9,6,1,0,0,1,9,5,0,7,1,1]
var cnt=0, cnt2=0

for number in array
{
    if (number % 2 == 0)
    {
        cnt=cnt+1
    }
    else
    {
        cnt2=cnt2+1
    }
}
print("짝수 개수는 :\(cnt) 홀수 개수는 :\(cnt2) ")

// 2. 표준체중 구하기

let array2=[158.3,182.4,132.1,175.4,163.2]
var weight:[Double]=[]
for item in array2
{
    weight+=[(item-100)*0.9]
}

//3. 연봉 구하기

let array3=[12, 23, 33, 44, 55, 62, 75, 87, 91, 109, 117, 123]
var sum=0

for item in array
{
    sum = sum + item
}